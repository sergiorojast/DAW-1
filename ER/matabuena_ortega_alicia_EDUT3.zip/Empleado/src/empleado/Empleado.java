/*
 * Ejercicio JUnit I.E.S. Trassierra
 * Clase Empleado
 */
package test.com;

/**
 * Clase Empleado
 * 
 * Esta clase almacena el nombre, la edad y el Dni de un empleado. La clase
 * contiene métodos de validación del DNI.
 * 
 * @author ldmoral1987 - Luis del Moral Martínez
 * @version 1.0
 */
public final class Empleado 
{
    // Variables del objeto Empleado.
    private String nombre;
    private int edad;
    private String dni;
    private String email;
    private float salarioBruto;
    private float salarioNeto;
    private int numeroPagas;
    
    // Esta variable estática almacena todas las letras posibles del DNI.
    private final String caracteresDNI = "TRWAGMYFPDXBNJZSQVHLCKE";
    
    /**
    * Constructor por defecto de la clase. Constructor vacío.
    */   
    public Empleado()
    {
        // Constructor vacío
    }
    
    /**
    * Constructor con argumentos de la clase Empleado. Este método
    * admite tres parámetros (el DNI deberá ser sometido a validación).
    * 
    * @param nombre Nombre del empleado
    * @param edad  Edad del empleado
    * @param dni DNI del empleado
    * @param email Email del empleado
    */    
    public Empleado(String nombre, int edad, String dni, String email) 
    {
        // Se asignan los atributos del objeto.
        this.setNombre(nombre);
        this.setEdad(edad);
        this.setDNI(dni);
        this.setEmail(email);
    }

    /**
    * Devuelve el nombre del empleado.
    * 
    * @return String Nombre del empleado
    */    
    public String getNombre() 
    {
        return nombre;
    }

    /**
    * Asigna el nombre del empleado. El nombre no puede contener enteros y
    * debe tener entre 3 y 25 caracteres.
    * 
    * @param nombre Nombre del empleado
    */      
    public void setNombre(String nombre) 
    {
        if (nombre.length() >= 3 && nombre.length() < 26 && !nombre.matches(".*\\d+.*"))
            this.nombre = nombre;
    }

    /**
    * Devuelve la edad del empleado.
    * 
    * @return String Nombre del empleado
    */  
    public int getEdad() 
    {
        return edad;
    }

    /**
    * Asigna la edad del empleado. El límite de edad está establecido entre 18 y 65.
    * 
    * @param edad Edad del empleado
    */         
    public void setEdad(int edad) 
    {
        if (edad >= 18 && edad < 66)
            this.edad = edad;
        else 
            this.edad = 0;
    }

    /**
    * Devuelve el DNI del empleado.
    * 
    * @return String DNI del empleado
    */      
    public String getDNI() 
    {
        return dni;
    }

    /**
    * Asigna el DNI del empleado. Este método comprueba si el DNI proporcionado 
    * es correcto. Si el DNI no cumple el formato, devuelve un error. Sin embargo,
    * si la letra del DNI no es correcta, la corrige y almacena el DNI en el objeto.
    * 
    * @param dni DNI del empleado
    * @return int Código de estado.
    *   <p><b>(-1)</b> - Longitud del DNI incorrecta.</p>
    *   <p><b>(-2)</b> - Formato del DNI incorrecto.</p>
    *   <p><b>(-3)</b> - La letra del DNI no es correcta. Se ha corregido.</p>
    *   <p><b>(-4)</b> - La letra del DNI no se ha indicado. Se ha corregido.</p>
    *   <p><b>(1)</b>  - DNI correcto.</p>
    */        
    public int setDNI(String dni) 
    {
        // Se comprueba si el DNI es correcto.
        if (dni.length() < 8 || dni.length() > 9)
        {   
            // El valor -1 indica que la longitud del DNI no es correcta.
            return -1;
        }
        else
        {
            // Comprobamos si los 8 primeros caracteres del DNI contienen 
            // únicamente dígitos.
            try {
                 // Extraemos los dígitos del DNI menos la letra.
                 int digitos = Integer.parseInt(dni.substring(0,8));
                 char letra;
                 letra = Character.MIN_VALUE;
                 
                 // Comprobamos si existe la letra del DNI y la extraemos
                 if (dni.length() == 9)
                 {
                     // Si existe la letra, la extraemos.
                     letra = dni.charAt(8);
                 }
                 
                 // Se comprueba si ha informado la letra del DNI.
                 if (Character.isLetter(letra))
                 {
                     if (caracteresDNI.contains(Character.toString(letra)))
                     {
                         // La letra del DNI existe.
                         // Ahora comprobamos si es la letra correcta.
                         char letraCorrecta = calcularLetraDNI(digitos);
                         
                         if (letra == letraCorrecta)
                         {
                             // La letra del DNI también es correcta.
                             // Se almacena el valor del DNI en el objeto.
                             this.dni = dni;
                             
                             // El valor 1 indica que el DNI es correcto.
                             return 1;
                         }
                         else
                         {
                             // La letra del DNI no es correcta.
                             // Se corrige la letra y se almacena la letra correcta.
                             String dniCorrecto = Integer.toString(digitos) + letraCorrecta;
                             this.dni = dniCorrecto;
                             
                             // El valor -3 indica que la letra no es correcta
                             // y ha sido corregida.
                             return -3;
                         }
                     }
                 }
                 else
                 {
                     // La letra del DNI no se ha informado.
                     // Se corrige la letra y se almacena la letra correcta.
                     char letraCorrecta = calcularLetraDNI(digitos);
                     String dniCorrecto = Integer.toString(digitos) + letraCorrecta;
                     this.dni = dniCorrecto;
                     
                     // El valor -4 indica que la letra no se ha indicado
                     // y ha sido corregida.
                     return -4;
                 }
            }
            catch (Exception e)
            {
                System.out.println(e.toString());
                
                // El valor -2 indica que los dígitos del DNI no son correctos
                // y pueden contener caracteres.
                return -2;
            }
        }
        
        // El valor -1 indica que la longitud del DNI no es correcta.
        return -1;
    }
    
    /**
    * Devuelve el email del empleado
    * 
    * @return String Email del empleado
    */    
    public String getEmail() 
    {
        return email;
    }

    
    /**
    * Asigna el email del empleado. Debe contener una arroba seguida de un punto
    * y tener una longitud mayor a 8 caracteres.
    * 
    * @param email Email del empleado
    */        
    public void setEmail(String email) 
    {
       if (email.matches(".*@.*\\..*") && email.length() >= 8)
           this.email = email;
    }

    /**
    * Devuelve el número de pagas del empleado
    * 
    * @return int Número de pagas del empleado
    */      
    public int getNumeroPagas()
    {
        return numeroPagas;
    }   
    
    /**
    * Devuelve el salario bruto del empleado
    * 
    * @return float Salario bruto del empleado
    */         
    public float getSalarioBruto() 
    {
        return salarioBruto;
    }

    /**
    * Devuelve el salario neto del empleado
    * 
    * @return float Salario neto del empleado
    */             
    public float getSalarioNeto() 
    {
        return salarioNeto;
    }
    
    /**
    * Calcula el salario neto y bruto del empleado. Esta función recibe el 
    * número de pagas, la base salarial, los complementos y los incentivos
    * del empleado para calcular y almacenar el salario neto y el salario bruto.
    * 
    * @param pagas Número de pagas del empleado
    * @param baseSalarial Base salarial bruta del empleado
    * @param complementos Complementos salariales mensuales del empleado
    * @param incentivos Incentivos anuales del empleado
    */       
    public void setSalario (int pagas, float baseSalarial, float complementos, float incentivos)
    {
        // La retención inicial es 0.0f (0%)
        float retenciones = 0.0f;
        
        // Se almacena el número de pagas.
        numeroPagas = pagas;
        
        // Se calcula y se almacena el salario bruto anual según la siguiente ecuación:
        // Salario Bruto = baseSalarial + (complementos * pagas) + incentivos
        salarioBruto = baseSalarial + (complementos * numeroPagas) + incentivos;
        
        // Se calculan las retenciones del empleado según las siguientes reglas:
        // Si el salario bruto está entre 8.000 y 11.999 -> retenciones = 2% del salario bruto
        // Si el salario bruto está entre 12.000 y 14.999 -> retenciones = 5% del salario bruto
        // Si el salario bruto está entre 15.000 y 16.999 -> retenciones = 7.5% del salario bruto
        // Si el salario bruto está entre 17.000 y 23.999 -> retenciones = 11% del salario bruto
        // Si el salario bruto está entre 24.000 y 29.999 -> retenciones = 14% del salario bruto
        // Si el salario bruto > 30.000 -> retenciones = 17% del salario bruto

        if (salarioBruto >= 8000 && salarioBruto < 12.000)
            retenciones = salarioBruto * 0.02f;
        else if (salarioBruto >= 12000 && salarioBruto < 15000)
            retenciones = salarioBruto * 0.05f;
        else if (salarioBruto >= 15000 && salarioBruto < 17000)
            retenciones = salarioBruto * 0.075f;
        else if (salarioBruto >= 17000 && salarioBruto < 24000)
            retenciones = salarioBruto * 0.11f;
        else if (salarioBruto >= 24000 & salarioBruto < 30000)
            retenciones = salarioBruto * 0.14f;
        else if (salarioBruto >= 30000)
            retenciones = salarioBruto * 0.17f;
                                       
        // Se calcula y se almacena el valor del salario neto
        salarioNeto = salarioBruto - retenciones;     
    }
    
    /**
    * Calcula la letra del DNI. Esta función recibe los dígitos del DNI en
    * formato int y devuelve la letra correcta, usando la variable final
    * caracteresDNI, que es una colección de todas las letras posibles del DNI.
    * 
    * @param dni DNI del empleado
    * @return char Letra del DNI.
    */            
    private char calcularLetraDNI (int dni)
    {
        return caracteresDNI.charAt(dni%23);
    }     
}
