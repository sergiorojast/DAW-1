/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package empleado;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import test.com.Empleado;

/**
 *
 * @author IES TRASSIERRA
 */
public class EmpleadoTest {
    
    public EmpleadoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

   

   

    /**
     * Test of setEdad method, of class Empleado.
     */
   
   
    /**
     * Test of setDNI method, of class Empleado.
     */
    @Test// CASO
    public void testSetDNI1() {//dni valido
        System.out.println("setDNI1");
        String dni = "30826805C";
        Empleado instance = new Empleado();
        //int expResult = 0;
        int result = instance.setDNI(dni);
        assertEquals(result, 1);
        
    }
     /**
     * Test of setDNI method, of class Empleado.
     */
    @Test// CASO 2
    public void testSetDNI2() {//longitud <8||>9
      System.out.println("setDNI2");
        String dni = "3082680";
        Empleado instance = new Empleado();
        //int expResult = 0;
        int result = instance.setDNI(dni);
        assertEquals(result,-1);
        
    }
     /**
     * Test of setDNI method, of class Empleado.
     */
    @Test// CASO
    public void testSetDNI3() {//con caracteres
      System.out.println("setDNI3");
        String dni = "308s6805C";
        Empleado instance = new Empleado();
        //int expResult = 0;
        int result = instance.setDNI(dni);
        assertEquals(result,-2);
        
    }
     /**
     * Test of setDNI method, of class Empleado.
     */
    @Test// CASO 4
    public void testSetDNI4() {//cambiando la letra
       System.out.println("setDNI4");
        String dni = "30826805F";
        Empleado instance = new Empleado();
        //int expResult = 0;
        int res=instance.setDNI(dni);
        assertEquals(res,-3);
        
    }
     /**
     * Test of setDNI method, of class Empleado.
     */
    @Test// CASO
    public void testSetDNI5() {
        System.out.println("setDNI5");
        String dni = "30826805";
        Empleado instance = new Empleado();
        //int expResult = 0;
        int result = instance.setDNI(dni);
        assertEquals(result,-4);
        
    }
    

  
    /**
     * Test of setEmail method, of class Empleado.
     */
    @Test  //caso 1
    public void testSetEmail() {//correcto
        System.out.println("setEmail");
        String email = "ali@gmail.com";
        Empleado instance = new Empleado();
        instance.setEmail(email);
        assertEquals(instance.getEmail(),email);
    }
      @Test 
      public void testSetEmail2() {//menor longitud
        System.out.println("setEmail2");
        String email = "a@gl.c";
        Empleado instance = new Empleado();
        instance.setEmail(email);
        assertEquals(instance.getEmail(),null);
    }
       @Test 
      public void testSetEmail3() {//sin @
        System.out.println("setEmail3");
        String email = "aligmail.com";
        Empleado instance = new Empleado();
        instance.setEmail(email);
        assertEquals(instance.getEmail(),null);
    }
       @Test 
       public void testSetEmail4() {//sin .
        System.out.println("setEmail3");
        String email = "ali@gmaicom";
        Empleado instance = new Empleado();
        instance.setEmail(email);
        assertEquals(instance.getEmail(),null);
    }



   

   
    
}
